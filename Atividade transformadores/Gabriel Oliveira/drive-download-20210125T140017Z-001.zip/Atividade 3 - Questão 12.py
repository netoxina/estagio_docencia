from numpy import angle, complex, degrees
from math import cos, sin, acos, pi

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
a = 230/13.8
s = 5000000

#Ensaio a Vazio:
v = 13800                   #V
I = 21.1                    #A
pot = 9800                  #W

#a) O teste foi realizado no lado de baixa tensão do transformador, então podemos usar os valores para encontrar diretamente o circuito equivalente. Logo,
Yex = I / v
angulo = acos(pot / (v*I))
Yex = complex(Yex*cos(angulo), Yex*sin(angulo))
Rc = 1 / Yex.real
Xm = 1 / Yex.imag
Zbase = (v**2) / s

#Sabendo que tem uma resistência por unidade de 1% e uma reatância por unidade de 5%, isto é:
Req = 0.01 * Zbase
Xeq = 0.05 * Zbase

#Assim, o circuito equivalente é:
Reqs = Req                          #Ohm
Xeqs = complex(0, Xeq)              #Ohm
Rcs = Rc                            #Ohm
Xms = Xm                            #Ohm
print('a) O circuito equivalente é constituido por: Req =', Reqs, ', Xeq =', Xeqs, ', Rc =', Rcs, 'e Xm =', Xms)

#b) Dados:
v2 = 13800                          #V
pot2 = 4000000                      #W
FP = 0.8                            #atrasado

Is = pot2 / (v2 * FP)
angc1 = acos(FP)                #rad
angc = -(acos(FP)*180)/pi       #graus
angc2 = ((angc+90)*pi)/180      #rad
Is1 = complex(Is*cos(-angc1), Is*sin(-angc1))
Is2 = complex(Is*cos(angc2), Is*sin(angc2))
Vp = v2 + Req*Is1 + Xeq*Is2
RT = ((Vp.real - v2) / v2) * 100         #%
print('b) A regulação de tensão é: RT =', RT)

#As perdas do cobre e do núcleo são, respectivamente:
Pcu = (Is**2) * Reqs            #W
Pnucleo = (Vp.real**2) / Rc
ef = pot2 / (pot2 + Pcu + Pnucleo) * 100    #%
print('A eficiência do transformador é: ef =', ef)