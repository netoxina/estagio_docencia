print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Rf = 512            #Ohm
Vg = 120            #V
Raf = 8             #Ohm
Np = 8
Ns = 1
a = Np / Ns
Zc = 8              #Ohm

#a): Inicialmente, calculamos a corrente da fonte:
Rt = Rf + Raf       #Ohm
If = Vg / Rt        #A
print('Corrente da Fonte para fig (a) =', If)

#Assim, para calcular a potência fornecida ao alto-falante, temos que:
Paf1 = (If**2) * Raf #W
print('a) Pot fornecida a carga =', Paf1)


#b): Inicialmente, calculamos a impedancia interna da fonte:
Zp = a**2 * Zc      #Ohm

#Assim, foi estabelecida as condições para a máxima transferência de potência. Logo, a corrente da fonte é:
Is = Vg / (Rf + Zp) #A
print('Corrente da Fonte para fig (b) =', Is)

#Do mesmo modo, para calcular a potência fornecida ao alto-falante:
Paf2 = (Is**2) * Zp #W
print('b) Pot fornecida ao Alto-falante =', Paf2)

#c): Comparando as potências:
x = Paf2 / Paf1     #W
print('c)', x)
#Logo, quando utilizamos o transformador, a potência é cerca de 16 vezes maior que quando não utilizamos.