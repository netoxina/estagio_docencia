from numpy import abs, angle, complex, degrees

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Np = 4
Ns = 1
Rp = 4                      #Ohm
Xp = 12                      #Ohm
Xs = 2                      #Ohm
Rs = 1                      #Ohm
Vg = 120                    #V
Xc = 20                     #Ohm

#a) Para achar a impedância total refletida no primário substituindo a carga resistiva da questão 13 por uma reatância indutiva de 20 ohms, temos que:
a = Np / Ns
Req = Rp + (a**2) * Rs      #Ohm
Xeq = Xp + (a**2) * Xs      #Ohm
Zp = complex(Req, Xeq + (a**2) * Xc)
#Assim, para encontrar o módulo da impedância total e o ângulo de fase:
ZP = abs(Zp)                    #Ohm
fi = degrees(angle(Zp))         #Graus
print('a) Impedância total =', Zp, '; Módulo da impedância total =', ZP, '; Ângulo de fase =', fi)

#b) A corrente no primário é dada por:
Ip = Vg / Zp
IP = abs(Ip)                    #A
fi2 = degrees(angle(Ip))        #Graus
print('b) Ip =', IP, '; Ângulo de fase =', fi2)

#c) As tensões em Req, Xeq e na carga refletida são, respectivamente:
Vreq = Ip * Req
VReq = abs(Vreq)                #V
print('c) Vreq =', VReq, '; Ângulo =', fi2)
Vxeq = Ip * complex(0, Xeq)
VXeq = abs(Vxeq)
fi3 = degrees(angle(Vxeq))
print('c) Vxeq =', VXeq, '; Ângulo =', fi3)
Vxc = Ip * ((a**2) * complex(0,Xc))
VXc = abs(Vxc)
fi4 = degrees(angle(Vxc))
print('c) Vxc =', VXc, '; Ângulo =', fi4)