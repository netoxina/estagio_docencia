from numpy import complex
from math import sqrt

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
v1 = 240                #Baixa tensão (V)
v2 = 2400               #Alta tensão  (V)
Poc = 254               #W
FP = 0.15

#A partir da potência ativa temos que:
Rc = (v1**2) / Poc
Soc = Poc / FP
#Para a potência reativa:
Qoc = sqrt(Soc**2 - Poc**2)
Xm = (v1**2) / Qoc

#Assim, obtemos a impedância total para o lado de baixa tensão:
Zoc = ((1/Rc) - (1/complex(0, Xm)))**(-1)

#Sabendo que P1 = P2 -> V1²/Z1 = V2²/Z2 -> V1²/Z1 = a²V1²/Z2 -> Z1 = Z2/a² ou Z2 = Z1/a². Desse modo, para a questão, temos que:
a = v2 / v1
Zocs = Zoc * (a**2)

#Portanto, a corrente fornecida é:
Iocs = v2 / Zocs
print('Corrente fornecida é: Iocs =', Iocs)