from numpy import abs, angle, complex, degrees
from math import sqrt, pi, sin, cos

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Req = 0.20              #Ohm
Xeq = 0.80              #Ohm
Rc = 300                #Ohm
Xm = 100                #Ohm
a = 0.5

#Como não há especificação no circuito equivalente, utilizamos o circuito equivalente referido ao lado primário. Assim,
Vs = 282.2 / sqrt(2)    #V
IsM = 7.07 / sqrt(2)    #A
ang = (-36.87)*pi / 180 #rad
Is = complex(IsM*cos(ang), IsM*sin(ang))

#A tensão e a corrente secundárias referidas ao lado primário são:
Vs1 = a * Vs            #V
Is1 = Is / a            #A

#A tensão do circuito primário é dada por:
Vp = Vs1 + (Is1 * complex(Req, Xeq))
VP = abs(Vp)

#A corrente de excitação deste transformador é: Iex = Ic + Im. Assim,
Iex = (Vp / Rc) + (Vp / complex(0, Xm))

#Logo, a corrente primária total é:
Ip = Iex + Is1
IP = abs(Ip)
fi = degrees(angle(Ip))
print('A corrente primária é: Ip =', Ip, '; o módulo da corrente é:', IP, '; o ângulo de fase é:', fi)

#A regulação da tensão do transformador nesta carga é:
RT = ((VP - a*Vs) / (a*Vs)) * 100   #%
print('A regulação da tensão é: RT =', RT)

#Para encontrar a eficiência encontramos as potências de entrada e saída primeiramente:
angulo1 = (2.8 - (-40))*pi / 180
Pe = VP * IP * cos(angulo1)
angulo2 = (36.87)*pi / 180
Ps = Vs * IsM * cos(angulo2)
ef = (Ps / Pe) * 100
print('Eficiência do transformador é:', ef)