print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Np = 1
Ns = 5
a = Np / Ns
Ip = 2                      #A
Zc = 2                      #Ohm

#a): Para calcular a corrente secundária, utilizamos a relação das espiras: Ip/Is = Ns / Np. Assim,
Ic = (Np / Ns) * Ip         #A

#Encontrado Ic, achamos a tensão Vc da maneira:
Vc = Ic * Zc                #V
print('a) Ic =', Ic, '/ Vc =', Vc)

#b): Calculando a resistência de entrada para os dados especificados, obtemos:
Zp = a**2 * Zc              #Ohm
print('b) Zp =', Zp)