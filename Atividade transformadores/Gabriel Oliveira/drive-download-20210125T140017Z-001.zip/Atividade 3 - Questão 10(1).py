from numpy import complex
from math import cos, sin, acos, pi

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
a = 230/115
s = 1000

#Ensaio de Curto-circuito:
v1 = 17.1                   #V
I1 = 8.7                    #A
pot1 = 38.1                 #W

#Ensaio a Vazio:
v2 = 115                    #V
I2 = 0.11                   #A
pot2 = 3.9                  #W

#a)
#Circuito Primário:
Z1 = v1 / I1
angulo1 = acos(pot1 / (v1*I1))
Zeq = complex(Z1*cos(angulo1), Z1*sin(angulo1))
Req = Zeq.real
Xeq = Zeq.imag

#Circuito Secundário:
Yex2 = I2 / v2
angulo2 = acos(pot2 / (v2*I2))
Yex = complex(Yex2*cos(angulo2), Yex2*sin(angulo2))
Rc = 1 / Yex.real
Xm = 1 / Yex.imag

#Assim, para converter o circuito equivalente para o lado de baixa tensão (secundário), dividimos a impedância em série por a².
#Observe que os elementos do ramo de excitação já estão no lado secundário. O circuito equivalente resultante é:
Reqs = Req / a**2
Xeqs = Xeq / a**2
Rcs = Rc
Xms = Xm
print('O circuito equivalente para o lado de BT é constituido por: Req =', Reqs, ', Xeq =', Xeqs, ', Rc =', Rcs, 'e Xm =', Xms)

#b) Para encontrar a regulação de tensão, iremos utilizar o circuito equivalente anterior. Assim,
Is = s / v2

#1°: FP (0.8) Atrasado
FP1 = 0.8
angc1 = acos(FP1)                #rad
angc = -(acos(FP1)*180)/pi       #graus
angc2 = ((angc+90)*pi)/180      #rad
Is1 = complex(Is*cos(-angc1), Is*sin(-angc1))
Is2 = complex(Is*cos(angc2), Is*sin(angc2))
Vp1 = v2 + Reqs*Is1 + Xeqs*Is2
RT1 = ((Vp1.real - v2) / v2) * 100         #%
print('b) FP 0.8 atrasado, temos que RT =', RT1)

#2°: FP (1.0)
FP2 = 1.0
angc3 = acos(FP2)                #rad
angcx = -(acos(FP2)*180)/pi       #graus
angc4 = ((angcx+90)*pi)/180      #rad
Is3 = complex(Is*cos(-angc3), Is*sin(-angc3))
Is4 = complex(Is*cos(angc4), Is*sin(angc4))
Vp2 = v2 + Reqs*Is3 + Xeqs*Is4
RT2 = ((Vp2.real - v2) / v2) * 100         #%
print('FP 1.0, temos que RT =', RT2)

#FP = 0.8 adiantado
FP3 = 0.8
angc5 = -acos(FP3)
angcy = (acos(FP3)*180)/pi       #graus
angc6 = -((angcy+90)*pi)/180      #rad
Is5 = complex(Is*cos(-angc5), Is*sin(-angc5))
Is6 = complex(Is*cos(angc6), Is*sin(angc6))
Vp3 = v2 + Reqs*Is5 + Xeqs*Is6
RT3 = ((Vp3.real - v2) / v2) * 100         #%
print('FP 0.8 adiantado, temos que RT =', RT3)

#c) Nas condições nominais e para FP 0.8 atrasado, temos que a potência de saída, as perdas do cobre e do núcleo são, respectivamente:
Ps = v2 * Is * cos(angc2)
Pcu = Is**2 * Reqs
Pnucleo = (Vp1.real**2) / Rc
ef = (Ps / (Ps + Pcu + Pnucleo)) * 100
print('c) A eficiência do transformador é =', ef)