from math import sqrt

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Vp = 70.7               #V
Pp = 10                 #W
Zc = 8                  #Ohm

#a): Considerando que não há perdas, a potência nos primários é a mesma que a nos secundários e, assim, a potência fornecida pela fonte é:
Pid = 4*Pp              #W
print('a) Potência em condições ideais =', Pid)


#b): Inicialmente, calculamos a corrente primária:
Ip = Pp / Vp            #A

#Assim, a impedância de entrada nos transformadores equivale a:
Zp = Vp / Ip            #Ohm
print('b) Impedância de entrada =', Zp)


#c): Relação de espiras "a":
a = sqrt(Zp / Zc)
print('c) a =', a, '. Assim, a relação é 8:1')


#d): A tensão aplicada aos alto-falantes:
Vs = Vc = Vp / a        #V
print('d) Tensão =', Vs)


#e): Como todos os alto-falantes estão em paralelo, temos que:
Rt1 = Zp
Rt2 = Zp / 2
Rt3 = Zp / 3
Rt4 = Zp / 4
print('d) Para 1 alto-falante =', Rt1,'/ Para 2 alto-falantes =', Rt2,'/ Para 3 alto-falantes =', Rt3,'/ Para 4 alto-falantes =', Rt4)