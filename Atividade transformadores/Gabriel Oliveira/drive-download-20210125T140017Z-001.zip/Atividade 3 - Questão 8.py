from numpy import angle, complex, degrees

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Rp = 5                      #Ohm
Xp = 6                      #Ohm
Rc = 50000                  #Ohm
Rs = 0.005                  #Ohm
Xs = 0.006                  #Ohm
Xm = 10000                  #Ohm
a = 8000 / 277
Pot = 100000                #V*A
Vbase = 277                 #V

#a) Para encontrar o circuito equivalente no lado de baixa tensão, primeiramente calculamos as impedâncias primárias referidas a este lado. Assim,
Rp2 = Rp / (a**2)           #Ohm
Xp2 = Xp / (a**2)           #Ohm
#Do mesmo modo, os elementos de ramificação de excitação referidos ao lado secundário são:
Rc2 = Rc / (a**2)           #Ohm
Xm2 = Xm / (a**2)           #Ohm
print('a) O circuito é constituido por, lado primário: Rp =', Rp2, 'e Xp =', Xp2, '; lado secundário: Rs =', Rs, 'e Xs =', Xs, '. Tendo como elementos de ramificação: Rc =', Rc2, 'e Xm =', Xm2)

#b) Através da potência nominal e a tensão nominal (Vbase), temos a corrente nominal:
Ibase = Pot / Vbase         #A
#Logo, a impedância da base no lado primário é:
Zbase = Vbase / Ibase       #Ohm
#Portanto, o circuito equivalente por unidade deste transformador basta dividir o Zatual pelo da base, obtendo:
Rp3 = Rp2 / Zbase           #Ohm
Xp3 = Xp2 / Zbase           #Ohm
Rc3 = Rc2 / Zbase           #Ohm
Xm3 = Xm2 / Zbase           #Ohm
Rs3 = Rs / Zbase            #Ohm
Xs3 = Xs / Zbase            #Ohm
print('b) O circuito é constituido por, lado primário: Rp =', Rp3, 'e Xp =', Xp3, '; lado secundário: Rs =', Rs3, 'e Xs =', Xs3, '. Tendo como elementos de ramificação: Rc =', Rc3, 'e Xm =', Xm3)

#c) Para simplificar o cálculo, simplificamos o circuito equivalente referido ao lado secundário obtendo:
Rsimp = Rp2 + Rs
Xsimp = Xp2 + Xs
Req = complex(Rsimp, Xsimp)
#A corrente secundária no transformador é:
Is = Pot / Vbase
fi = -31.8                  #Graus
#Logo, a tensão de entrada no transformador é:
Vp = Vbase + (Rsimp * Is)
fi2 = degrees(angle(Req)) + fi
#e a regulação de tensão corresponde a:
RT = ((Vp - Vbase) / Vbase) * 100  #%
print('c) A tensão de entrada é: Vp =', Vp, '; ângulo de fase:', fi2, '. A regulação de tensão é: RT =', RT)

#d)
Pcu = (Is**2) * Rsimp              #W
Pnucleo = (Vp**2) / Rc2            #W
print('d) Perda no cobre e no núcleo são, respectivamente: Pcu =', Pcu, 'e Pnucleo =', Pnucleo)

#e) Para encontrarmos a eficiência é preciso calcular a perda de saída:
Ps = Pot * 0.85                    #W
n = (Ps / (Ps + Pcu + Pnucleo)) * 100   #%
print('e) A eficiência do transformador é:', n)