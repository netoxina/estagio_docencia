from numpy import angle, complex, degrees
from math import cos, sin, acos, pi

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
a = 12000/240
s = 100000
Inom = s/12000
FP = 0.8

#Ensaio de Curto-circuito:
pot1 = 1200              #W
v1 = 600                 #V

#Ensaio à Vazio:
pot2 = 480               #W
v2 = 240                 #V
I2 = 8.75                #A

#Para o circuito equivalente primário, temos que:
Z1 = v1 / Inom
angulo1 = acos(pot1/(v1*Inom))
Zp = complex(Z1*cos(angulo1), Z1*sin(angulo1))
ZP = abs(Zp)
Req = Zp.real / a**2
Xeq = Zp.imag / a**2
print('O circuito equivalente primário é constituido por: Zp =', ZP, ', Rc =', Zp.real, ', Xp =', Zp.imag, ', Req =', Req, 'e Xeq =', Xeq)

#Para o circuito equivalente secundário:
Yex2 = I2 / v2
angulo2 = acos(pot2 / (v2*I2))
Yex = complex(Yex2*cos(angulo2), -Yex2*sin(angulo2))
YEx = abs(Yex)
RC = 1/Yex.real
Xm = 1/(-Yex.imag)
print('O circuito equivalente secundário é constituido por: Yex2 =', YEx, ', RC =', RC, 'e XM =', Xm)

Ic = s / v2
angc1 = acos(FP)                #rad
angc = -(acos(FP)*180)/pi       #graus
angc2 = ((angc+90)*pi)/180      #rad
Ic1 = complex(Ic*cos(-angc1), Ic*sin(-angc1))
Ic2 = complex(Ic*cos(angc2), Ic*sin(angc2))
Va = v2 + Req*Ic1 + Xeq*Ic2
RT = (abs(Va) - v2)/v2
print('A regulação de tensão corresponde a (%):', RT*100)