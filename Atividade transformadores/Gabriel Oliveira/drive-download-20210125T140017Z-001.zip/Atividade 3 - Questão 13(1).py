from numpy import abs, angle, complex, degrees

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
Rp = 4                      #Ohm
Xp = 8                      #Ohm
Xs = 2                      #Ohm
Rs = 1                      #Ohm
a = 4
Rc = 20                     #Ohm
Vg = 120                    #V

#a) Para calcular a resistência equivalente, temos que:
Req = Rp + (a**2)*Rs        #Ohm
print('a) Req =', Req)

#b) Do mesmo modo que no item anterior, para a reatância equivalente, obtemos:
Xeq = Xp + (a**2)*Xs        #Ohm
print('b) Xeq =', Xeq)

#c) O circuito equivalente refletivo para o primário é constituído de Vg, Req, Xeq e aVc. Assim, o circuito equivalente é:
x = (a**2) * Rc             #Ohm
print('c) Circuito equivalente possui: Vg =', Vg, '; Req =', Req, '; Xeq =', Xeq, '; a²Rc =', x)

#d) A corrente equivalente no primário para um Vg = 50V, corresponde a:
Zp = complex(Req + x, Xeq)
Ip = Vg / Zp
#Para encontrar o módulo da corrente e o ângulo de fase:
IP = abs(Ip)                        #A
fi = degrees(angle(Ip))             #Graus
print('d) Corrente equivalente no primário =', Ip, 'Módulo da corrente equivalente no primário =', IP, '; Ângulo de fase:', fi)

#e) O módulo da tensão na carga Vc é:
Vc = a * Ip * Rc                    #V
VC = abs(Vc)
fi2 = degrees(angle(Vc))
print('e) Vc =', VC, '; Ângulo de fase:', fi2)