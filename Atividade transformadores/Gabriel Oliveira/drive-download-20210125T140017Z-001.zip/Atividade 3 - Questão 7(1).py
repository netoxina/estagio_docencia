from math import acos, sin, cos, pi

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
s = 250000
a = 24200/220
FP = 0.92

#Ensaio de Curto-Circuito:
pot1 = 1700                 #W
v1 = 600                    #V
I1 = Inom = s/24200 * 0.85  #A (85% da carga)

#Ensaio a Vazio:
pot2 = 1200                 #W
I2 = 16                     #A
v2 = vnom = 220 * 0.85      #V (85% da carga)

#a) Para o circuito equivalente primário (lado de alta tensão - Curto-Circuito) temos:
Z1 = v1 / Inom              #Parte absoluta
angulo1 = acos(pot1/(v1*Inom))
Zp = complex(Z1*cos(angulo1), Z1*sin(angulo1))
ZP = abs(Zp)
Req = Zp.real/a**2
Xeq = Zp.imag/a**2
print('a) O circuito equivalente primário é constituido por: Zp =', ZP, ', Rc =', Zp.real, ', Xp =', Zp.imag, ', Req =', Req, 'e Xeq =', Xeq)

#para o circuito equivalente secundário (lado de baixa tensão - a Vazio), temos que:
Yex2 = I2 / v2              #Parte absoluta
angulo2 = acos(pot2/(v2*I2))
Yex = complex(Yex2*cos(angulo2), -Yex2*sin(angulo2))
Rc2 = 1/Yex.real
Xm2 = 1/-Yex.imag
print('O circuito equivalente secundário é constituido por: Yex =', Yex, ', Rc =', Rc2, 'e Xm =', Xm2)

#b)
Ic = s / v2
angc1 = acos(FP) #rad
angc = -(acos(FP)*180)/pi #graus
angc2 = ((angc+90)*pi)/180 #rad
Ic1 = complex(Ic*cos(-angc1), Ic*sin(-angc1))
Ic2 = complex(Ic*cos(angc2), Ic*sin(angc2))
VA = v2 + Req*Ic1+ Xeq*Ic2
RT = (abs(VA) - v2) / v2
print('b) A regulação de tensão é: RT =', RT)