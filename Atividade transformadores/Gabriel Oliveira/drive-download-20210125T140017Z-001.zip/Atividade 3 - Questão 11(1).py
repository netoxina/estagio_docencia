from numpy import angle, complex, degrees
from math import cos, sin, acos, pi

print('Aluno: Gabriel Oliveira Senra Carneiro')
#Dados da Questão:
s = 30000
a = 8000/230

#Circuito Primário:
Z1 = complex(20, 100)
Rc = 100000
Xm = 20000

#a) Dados:
v1 = 7967
Zc = complex(2, 0.7)
#Passando todos os componentes para o lado primário do transformador, temos que:
Zc1 = (a**2) * Zc
Is = v1 / (Z1 + Zc1)
vs1 = Is * Zc1
#Assim, a tensão secundária do transformador é:
vs = vs1 / a            #V
Vs = abs(vs)
fi = degrees(angle(vs))
print('a) A tensão secundária do transformador é: Vs=', vs,'. O módulo da tensão é: |Vs| =', Vs, 'e o ângulo de fase é:', fi)
VR = ((v1 - vs1.real) / vs1.real) * 100         #%
print('A regulação de tensão do transformador é: VR =', VR)

#b) Dados:
Z = complex(0, -3)
#Do mesmo modo que no item anterior, passando os componentes para o lado primário, temos que:
Zc2 = (a**2) * Z
Is2 = v1 / (Z1 + Zc2)
vs2 = Is2 * Zc2
#Assim, a tensão secundária do transformador é:
vs_ = vs2 / a           #V
Vs_ = abs(vs_)
fi2 = degrees(angle(vs_))
print('b) A tensão secundária do transformador é: Vs=', vs_,'. O módulo da tensão é: |Vs| =', Vs_, 'e o ângulo de fase é:', fi2)
RT = ((v1 - vs2.real) / vs2.real) * 100         #%
print('A regulação de tensão do transformador é: RT =', RT)